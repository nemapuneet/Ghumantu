﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class onmousedown : MonoBehaviour {
	public GameObject objectclick;
	public int num;

	public void OnMouseDown(){
		int lang = PlayerPrefs.GetInt ("lang");
		int page = (num * 10) + lang+1;
		Debug.Log (page);
		SceneManager.LoadScene ("knowrajasthan/"+page , LoadSceneMode.Single);
	}
}
