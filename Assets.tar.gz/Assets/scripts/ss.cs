﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ss : MonoBehaviour {
	public string fname = null;
	// Use this for initialization
	void Start () {
		StartCoroutine ("countdown");
	}
	
	public IEnumerator countdown(){
		yield return new WaitForSeconds (3);
		fname = PlayerPrefs.GetString ("first_name");

		if (fname != "") {
			Debug.Log (fname);
			SceneManager.LoadScene ("mainmenu", LoadSceneMode.Single);
		} else {
			Debug.Log (fname);
			SceneManager.LoadScene ("register", LoadSceneMode.Single);
		}
	}
}
