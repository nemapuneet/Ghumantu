﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class login : MonoBehaviour {
	string url = "http://192.168.191.50:8080/ghumantu/login.php";
	public InputField iusername;
	public InputField ipassword;
	// Use this for initialization

	public string[] items;
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	public void clickbutton(){
		StartCoroutine(logintoDB (iusername.text,ipassword.text));
	}

	IEnumerator logintoDB(string username,string password){
		WWWForm form = new WWWForm ();
		form.AddField ("usernamep",username);
		form.AddField ("passwordp",password);

		WWW www = new WWW (url,form);
		yield return www;
		Debug.Log (www.text);
		string itemsdata = www.text;
		items = itemsdata.Split ('|');

		if(items[0] == "success"){
			PlayerPrefs.SetString ("first_name", items[1]);
			PlayerPrefs.SetString ("last_name", items[2]);
			PlayerPrefs.SetString ("email", items[3]);
			PlayerPrefs.SetString ("phone", items[4]);
			PlayerPrefs.Save ();
			SceneManager.LoadScene ("mainmenu", LoadSceneMode.Single);
		}
	}
		
}
