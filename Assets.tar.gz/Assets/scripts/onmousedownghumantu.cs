﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class onmousedownghumantu : MonoBehaviour {
	public int img;
	public int marker;
	public GameObject objectclick;
	public void OnMouseDown(){
		int lang = PlayerPrefs.GetInt ("lang");
		int page = (img * 100) + (marker * 10) + (lang + 1);
		Debug.Log (page);
		SceneManager.LoadScene ("gowithghumantu/"+page , LoadSceneMode.Single);
	}
}
