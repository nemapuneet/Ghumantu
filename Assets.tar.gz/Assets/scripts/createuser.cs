﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class createuser : MonoBehaviour {
	public InputField ifname;
	public InputField ilname;
	public InputField iemail;
	public InputField iccode;
	public InputField iphoneno;
	public InputField iusername;
	public InputField ipassword;

	string url = "http://192.168.191.50:8080/ghumantu/insertuser.php";
	// Use this for initialization
	public void clickbutton(){
		//Debug.Log ("inside clickbutton");
		StartCoroutine(createUser (ifname.text,ilname.text,iemail.text,iccode.text,iphoneno.text,iusername.text,ipassword.text));
	}

	public IEnumerator createUser(string fname,string lname,string email,string ccode,string phoneno,string username,string password){
		Debug.Log ("inside create User");
		WWWForm form = new WWWForm ();
		form.AddField ("fnamep",fname);
		form.AddField ("lnamep",lname);
		form.AddField ("emailp",email);
		form.AddField ("ccodep",ccode);
		form.AddField ("phonenop",phoneno);
		form.AddField ("usernamep",username);
		form.AddField ("passwordp",password);
		//Debug.Log ("before www");
		WWW www = new WWW (url, form);
		yield return www;
		if (www.text == "fine") {
			//Debug.Log ("inside fine");
			SceneManager.LoadScene ("login", LoadSceneMode.Single);
		}
	}
}
