﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class loadscene : MonoBehaviour {
	public int num;
	public void onClickButton(int num){
		Application.LoadLevel (num);
	}
}
