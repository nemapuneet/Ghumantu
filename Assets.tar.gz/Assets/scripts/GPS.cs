﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GPS : MonoBehaviour {
	public static GPS Instance { set; get; }
	public float latitude;
	public float longitude;
	string url= "https://anshali.000webhostapp.com/mail.php";

	private void Start(){
		Instance = this;
		DontDestroyOnLoad (gameObject);
		StartCoroutine (StartLocationService());
	
	}
	private IEnumerator StartLocationService(){
	
		if(!Input.location.isEnabledByUser){
			Debug.Log ("user has not enabled GPS");
			yield break;
	}

		Input.location.Start ();
		int maxwt = 30;


		while (Input.location.status == LocationServiceStatus.Initializing && maxwt > 0) {
			
			yield return new WaitForSeconds (1);
			maxwt--;
		}
		
		if (maxwt <= 0) {
			Debug.Log ("Timed OUT");
			yield break;
		
		}
		if (Input.location.status == LocationServiceStatus.Failed) {
			Debug.Log ("Unable to find device location");
		}
			latitude = Input.location.lastData.latitude;
			longitude = Input.location.lastData.longitude;

		Debug.Log (latitude);
		Debug.Log (longitude);

		sendLatLong (latitude,longitude);

			yield break;

		}
	public void sendLatLong(float latitude,float longitude)
	{
		string lat1 = latitude.ToString ();
		string long1 = longitude.ToString ();

		WWWForm form = new WWWForm ();
		form.AddField ("latp",lat1);
		form.AddField ("longp", long1);
		WWW www = new WWW (url, form);
	}
}
