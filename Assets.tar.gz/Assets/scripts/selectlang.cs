﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class selectlang : MonoBehaviour {

	//Attach this script to a Dropdown GameObject
	public Dropdown Dropdown;
	public int level;
	//This is the string that stores the current selection m_Text of the Dropdown
	//This Text outputs the current selection to the screen
	//This is the index value of the Dropdown

	public void lang(int level)
	{
		//Fetch the DropDown component from the GameObject
		Dropdown = GetComponent<Dropdown>();
		//Output the first Dropdown index value
	    int value = Dropdown.value;
		PlayerPrefs.SetInt("lang", value);
		Application.LoadLevel (level);
	}


}
