﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PopUpWindow : MonoBehaviour {
	public GameObject window;
	public Text messageFeild;

	//gps
	//public static GPS Instance { set; get; }
	public float latitude;
	public float longitude;
	string url= "http://192.168.191.50:8080/ghumantu/mail.php";
	//gpsover

	private void Start(){
		//Instance = this;
		DontDestroyOnLoad (gameObject);
		StartCoroutine (StartLocationService());

	}
	private IEnumerator StartLocationService(){

		if(!Input.location.isEnabledByUser){
			Debug.Log ("user has not enabled GPS");
			yield break;
		}

		Input.location.Start ();
		int maxwt = 30;


		while (Input.location.status == LocationServiceStatus.Initializing && maxwt > 0) {

			yield return new WaitForSeconds (1);
			maxwt--;
		}

		if (maxwt <= 0) {
			Debug.Log ("Timed OUT");
			yield break;

		}
		if (Input.location.status == LocationServiceStatus.Failed) {
			Debug.Log ("Unable to find device location");
		}
		latitude = Input.location.lastData.latitude;
		longitude = Input.location.lastData.longitude;

		yield break;

	}


	public void Show(string message)
	{  message = "Click okay to confirm!";
		messageFeild.text = message;
		window.SetActive(true);
	}

	public void confirmbutton(){
		Confirm();
	}
	public void Confirm(){
		window.SetActive(false);
		/*string lat1 = latitude.ToString ();
		string long1 = longitude.ToString ();
		string fname = PlayerPrefs.GetString ("first_name");
		string lname = PlayerPrefs.GetString ("last_name");
		string email = PlayerPrefs.GetString ("email");
		string phone = PlayerPrefs.GetString ("phone");

		WWWForm form = new WWWForm ();
		form.AddField ("latp",lat1);
		form.AddField ("longp", long1);
		form.AddField ("fnamep", fname);
		form.AddField ("lnamep", lname);
		form.AddField ("emailp", email);
		form.AddField ("phonep", phone);
		WWW www = new WWW (url, form);

		yield return www;
		if (www.text == "success") {
			SceneManager.LoadScene ("success", LoadSceneMode.Single);
		}*/
		window.SetActive(false);
		SceneManager.LoadScene ("success", LoadSceneMode.Single);

	}
}
